  <!-- footer-style4 -->
  <footer class="footer-style4">
      <div class="container footer-shell4">
          <div class="footer-top4">
              <div class="footer-content4">
                  <h2 class="title">Technofra helps businesses unlock their online potential</h2>
                  <a href="contact.php" title="Contact Us" class="ibt-btn ibt-btn-outline footer-cta4">
                      <span>Contact Us</span>
                      <i class="icon-arrow-top"></i>
                  </a>
              </div>
          </div>
          <div class="widget-area footer-main4">
              <div class="footer-grid4">
                  <div class="about-widget4 footer-widget">
                      <div class="footer-logo">
                          <img src="assets/images/new/logo.png" alt="Technofra">
                      </div>
                      <p>Technofra helps businesses unlock their online potential with innovative web design and development solutions.</p>
                      <p>We create strong digital experiences that grow your brand and deliver real results.</p>

                  </div>
                  <div class="footer-links footer-widget">
                      <h3 class="widget-title">Services</h3>
                      <ul>
                          <li><a href="web-design-and-development.php" title="Website Development">Website Development</a></li>
                          <li><a href="android-app-development.php" title="App Development">App Development</a></li>
                          <li><a href="crm-development.php" title="E-Commerce Development">CRM Development</a></li>
                          <li><a href="https://markidentitiez.com/" title="Branding">Branding</a></li>
                          <li><a href="digital-marketing.php" title="Digital Marketing">Digital Marketing</a></li>
                          <li><a href="social-media-marketing.php" title="Social Media Marketing">Social Media Marketing</a></li>
                      </ul>
                  </div>
                  <div class="footer-links footer-widget">
                      <h3 class="widget-title">Quick Links</h3>
                      <ul>
                          <li><a href="about-us.php" title="About Us">About Us</a></li>
                          <li><a href="portfolios.php" title="Portfolio">Portfolio</a></li>
                          <li><a href="blog" title="Blog">Blog</a></li>
                          <li><a href="privacy-policy.php" title="Privacy Policy">Privacy Policy</a></li>
                          <li><a href="refund-policy.php" title="Refund Policy">Refund Policy</a></li>
                          <li><a href="sitemap.html" title="Sitemap">Sitemap</a></li>
                      </ul>
                  </div>
                  <div class="location-widget4 footer-widget">
                      <h3 class="widget-title">Contact Info</h3>
                      <div class="footer-contact-item4">
                          <span class="footer-icon4"><i class="fas fa-map-marker-alt"></i></span>
                          <p>Office No. 501, 5th Floor, Ghanshyam Enclave, New Link Road, Kandivali (West), Mumbai - 400067, Maharashtra - INDIA.</p>
                      </div>
                      <div class="footer-contact-item4">
                          <span class="footer-icon4"><i class="fas fa-phone-alt" style="display:inline-block;transform:scaleX(-1);"></i></span>
                          <div class="contact-widget4">
                              <a href="tel:+918080803374" title="Call Technofra" class="nmbr">+91 8080 80 3374</a>
                              <a href="tel:+918080803375" title="Call Technofra" class="nmbr">+91 8080 80 3375</a>
                          </div>
                      </div>
                      <div class="footer-contact-item4">
                          <span class="footer-icon4"><i class="fas fa-envelope"></i></span>
                          <div class="contact-widget4">
                              <a href="mailto:info@technofra.com" title="Email Technofra" class="gmail">info@technofra.com</a>
                              <a href="mailto:support@technofra.com" title="Email Technofra support" class="gmail">support@technofra.com</a>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <div class="footer-app-social4">

              <div class="footer-social-row4">
                  <h4 class="mb-0">Follow us</h4>
                  <ul class="social-icon footer-social4">
                      <li><a href="https://www.facebook.com/technofra/" title="Facebook" target="_blank" rel="noopener" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a></li>
                      <li><a href="https://x.com/Technofra_" title="X" target="_blank" rel="noopener" aria-label="X"><i class="fab fa-x-twitter"></i></a></li>
                      <li><a href="https://www.linkedin.com/company/technofra/" title="LinkedIn" target="_blank" rel="noopener" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a></li>
                      <li><a href="https://youtube.com/@technofra?si=bSGDnJfZ6HMZd2Uw" title="YouTube" target="_blank" rel="noopener" aria-label="YouTube"><i class="fab fa-youtube"></i></a></li>
                      <li><a href="https://www.instagram.com/technofra.company/" title="Instagram" target="_blank" rel="noopener" aria-label="Instagram"><i class="fab fa-instagram"></i></a></li>
                  </ul>
              </div>
              <div class="footer-apps4">
                  <a href="https://play.google.com/store/apps/details?id=com.technofra.mycrm&pcampaignid=web_share" target="_blank" rel="noopener" title="Get it on Google Play">
                      <img src="assets/images/new/app.webp" alt="Get it on Google Play">
                  </a>
                  <a href="https://apps.apple.com/in/app/my-crm-complete-business-crm/id6792998604" target="_blank" rel="noopener" title="Download on the App Store">
                      <img src="assets/images/new/ios.webp" alt="Download on the App Store">
                  </a>
              </div>
          </div>
          <div class="footer-brands4">
              <div class="footer-brand-group4 footer-partners4">
                  <h4>Our Partners</h4>
                  <div class="footer-brand-logos4">
                      <img src="assets/images/parnters/office356.webp" alt="Office 365">
                      <img src="assets/images/parnters/payumoney.webp" alt="PayUMoney">
                      <img src="assets/images/parnters/razorpay.webp" alt="Razorpay">
                      <img src="assets/images/parnters/gridmce.webp" alt="GridMCE">
                  </div>
              </div>
              <div class="footer-brand-group4 footer-own-brands4">
                  <h4>Our Brands</h4>
                  <div class="footer-brand-logos4">
                      <img src="assets/images/brand/blueorbith.png" alt="Blue Orbith">
                      <img src="assets/images/brand/grid-infinity.png" alt="Grid Infinity">
                      <img src="assets/images/brand/digikcon.png" alt="Digikkon">
                      <img src="assets/images/brand/markidentitiez.png" alt="Mark Identitiez">
                  </div>
              </div>
          </div>
          <div class="footer-bottom4">
              <ul class="footer-bottom-nav4">
                  <li><a href="our-team.php">Our Team</a></li>
                  <li><a href="web&appmaintenance.php">Web & APP Maintenance</a></li>
                  <li><a href="blog">Blog</a></li>
                  <li><a href="privacy-policy.php">Privacy Policy</a></li>
                  <li><a href="refund-policy.php">Refund Policy</a></li>
                  <li><a href="sitemap.html">Sitemap</a></li>
              </ul>
              <p>© 2026 <a href="https://technofra.com/" target="_blank" rel="noopener">Technofra</a>. All Rights Reserved.</p>
          </div>
      </div>
  </footer>
  <!-- footer-style4 -->
  <div class="sticky-contact-actions" aria-label="Quick contact actions">
      <a
          href="https://wa.me/918080803374"
          class="sticky-contact-btn sticky-whatsapp-btn"
          title="Chat on WhatsApp"
          target="_blank"
          rel="noopener"
          aria-label="Chat on WhatsApp">
          <i class="fab fa-whatsapp"></i>
      </a>
      <button id="scrollBtn" class="sticky-contact-btn sticky-scroll-btn" title="Go to top" aria-label="Go to top">
          <i class="fas fa-angle-up"></i>
      </button>
  </div>
  </div>

  <!-- Js Plugin -->
  <script src="assets/js/bootstrap.min.js" defer></script>
  <?php if (empty($lightJs)): /* light pages skip slider/animation/smooth-scroll libraries */ ?>
  <script src="assets/js/vendor/swiper-bundle.min.js" defer></script>
  <script src="assets/js/vendor/lenis.min.js" defer></script>
  <script src="assets/js/vendor/gsap.min.js" defer></script>
  <script src="assets/js/vendor/ScrollTrigger.min.js" defer></script>
  <?php endif; ?>
  <script src="assets/js/main.min.js" defer></script>
  </body>

  </html>
